﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//namespace
namespace PalasProject.Models.Impl
{
    public class Person
    {
        //add empty line between all declarations
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
